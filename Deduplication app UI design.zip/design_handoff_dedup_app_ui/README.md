# Handoff: Rusty FClone Desktop UI (v2)

## Overview
A dark-mode desktop UI for `rusty_fclone`, rebuilt against the real backend after the initial mockup was reconciled with the repo (see `docs/decisions/ADR-0022-gui-redesign.md` and the ADRs it references). Screens: Dashboard, Scan Setup, Duplicate Review (file, folder, and perceptual-match groups), and Rules & Automation.

## About the Design Files
`RustyFClone-design.html` + `support.js` are a **working, interactive HTML/JS design reference** — open `RustyFClone-design.html` directly in a browser (both files must sit in the same folder). This is a design reference, not production code: recreate it inside `crates/rusty_fclone-gui`, wiring to the real Tauri commands in `commands.rs` / `payload.rs`, not the mock data in this file's `GROUPS`/`SIMILAR_GROUPS` constants.

## Fidelity
High-fidelity for layout, color, type, and interaction states. This version already reflects the real backend's constraints (see below) rather than an idealized mock — implement close to literally, adjusting only copy/microcopy as needed.

## Grounding in the real backend
This iteration was corrected against `baileyrd/rusty_fclone`'s ADRs through ADR-0030. Key facts baked into the design:

- **One scan root, not a folder checklist** — `rusty_fclone_core::scan` takes exactly one directory (ADR-0022). Scan Setup has a single "Folder to scan" field, now with a **Browse… button** that opens a folder-tree picker modal (mocked against a static filesystem tree here — the real app still has no native file/directory picker, per `GUI-UX-001`'s standing non-goal, so this modal is a **forward-looking affordance**, not a claim that one exists today. Flag this to the team: either build a real in-app tree browser matching this modal, or treat it as illustrative until a native picker lands).
- **Action kinds: Delete, Trash, Hardlink, Reflink, Move, Copy** (`ActionKind` — ADR-0024 added Trash, ADR-0026 added Move/Copy with an archive-folder destination). The Review action bar's pill row reflects all six; Move/Copy reveal an "Archive folder path" field and Apply is disabled until it's filled in.
- **Folder-level action is real** (ADR-0023) — folder duplicate groups get the same Delete/Trash/Hardlink/Reflink action bar as file groups (scoped to those four kinds; Move/Copy aren't modeled at folder granularity here), plus the Exact/Contained match badge from ADR-0021.
- **Protected/reference folders are a hard guardrail** (ADR-0025) — Scan Setup has a "Protected folders" field; in Review, a file under a protected path shows a locked "Kept — protected folder" badge and can't be flipped to "marked for removal."
- **"Similar content" is a real, opt-in, additive pass** (ADR-0030, dHash-based) — it never replaces exact matching. The Scan Setup control is a toggle ("Also find similar photos"), not the old either/or segmented control. Matching clusters render in Review as separate, visually distinct, warning-tinted, **read-only** cards (no keep-choice, only "Skip") — never confused with confirmed-identical groups.
- **Saved scan profiles** (ADR-0029) — a "Saved scan profiles" card (name + Save current, list with Load/Delete) mirrors the real `{name, root, ScanOptions}` JSON-file persistence.
- **Apply is gated by a confirmation dialog**, not a checkbox (ADR-0022) — clicking Apply opens a modal naming the action and effect; only confirming applies it.
- **Dashboard and Rules are honestly labeled as not-yet-real**: Dashboard's stats/history are session-only (Import history / Export (JSON) render disabled with a tooltip pointing at the CLI's `--history` flag); Rules & Automation carries a "Preview only" pill — no rule engine or persistence exists yet.
- Wire types to reuse: `ScanOptionsPayload`, `ActionPlanPayload`/`ApplyReportPayload`, `FolderActionPlan`/`FolderApplyReport`, `ScanEventPayload`, `GroupPayload`, `ScanProfilePayload` — all in `crates/rusty_fclone-gui/src/payload.rs`.

## Screens

### 1. Dashboard
Session-scoped stat cards, a storage-breakdown bar, and a "Recent scans" table. Import/Export are disabled with a tooltip (no GUI-side history reader exists yet). Sidebar shows a live "Applied this session" action count instead of a persisted total.

### 2. Scan Setup
Single "Folder to scan" field + **Browse… button** (opens the folder-picker modal). Right column: "Also find similar photos" toggle (opt-in perceptual pass), file-type chips that filter *Review's display* (not the scan), and three real `ScanOptions` toggles (follow symlinks, cross filesystems, verify matches). Below: "Data & caching" (hash cache path, fclones cache import — ADR-0016/0019), "Protected folders" (ADR-0025), and "Saved scan profiles" (ADR-0029).

### 3. Duplicate Review
Three-panel layout, all independently collapsible to reclaim width:
1. **File System panel** — a real filesystem tree rooted at `/`, colored by scan status: accent + count badge for folders directly holding duplicates, normal text for ancestor folders, muted for untouched ones (Applications, Library, System, Volumes). Click a folder to filter the duplicate list to it (with a clear-filter chip); folders with nothing found show a friendly empty state.
2. **Duplicate-group panel** — a nested folder tree (matching real path hierarchy, e.g. Documents › Finance) grouping duplicate groups by where they actually live, instead of a flat list.
3. **Compare + action panel** — a breadcrumb, horizontally-scrollable N-copy compare cards (not just 2), and a pinned action bar (never scrolls out of view) with the action-kind pills, optional archive-folder field, and Skip/Apply (Apply opens the confirm dialog).

Perceptual "similar" clusters appear in the same tree, visually tagged, and open into read-only warning-banner cards with only a "Skip" action.

The main app nav sidebar also collapses to an icon-only 64px rail via a toggle at its base, freeing width for the three Review panels.

### 4. Rules & Automation
Same list-of-rule-cards layout as before, now carrying an explicit "Preview only" pill and honest copy: nothing here is persisted or enforced during a scan.

## Design Tokens
Unchanged from the prior handoff except:
- **Font stack is now system UI** (`-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif`), not a Google Fonts webfont — this app works offline, and a webfont fetch on startup would be a real regression (ADR-0022).
- Theme neutrals, the 5 accent palettes (Indigo/Teal/Violet/Amber/Slate), and the kind→palette-slot mapping (photo→accent, document→warning, video→purple, audio→success, folder→pink) are unchanged — see the palette definitions at the top of the file's script for exact hex values.
- Window is no longer a fake bezel — no traffic lights, no drop shadow, no rounded artboard (ADR-0022: "no fake OS window chrome" — the real Tauri window already has real chrome). The design now fills its frame edge-to-edge like the real app will.

## Files
- `RustyFClone-design.html` + `support.js` — the interactive design reference. Open the `.html` file directly (same folder as `support.js`).
- `screenshots/01-dashboard.png`, `02-scan-setup.png`, `03-scan-browse-modal.png`, `04-duplicate-review.png` (file group), `05-review-folder-match.png` (folder group), `06-rules.png`.
