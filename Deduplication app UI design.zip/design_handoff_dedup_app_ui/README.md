# Handoff: Rusty FClone Desktop UI

## Overview
A sleek, professional desktop UI for `rusty_fclone` — a Rust file/folder deduplication tool with an existing Tauri GUI shell (`crates/rusty_fclone-gui`). This design replaces the current bare-bones/unstyled prototype UI (`crates/rusty_fclone-gui/ui/index.html`, `app.js`, `style.css`) with a full IA: Dashboard, Scan Setup, Duplicate Review (file- and folder-level), and Rules & Automation, plus light/dark theming and 5 accent-color palettes.

## About the Design Files
The bundled file (`RustyFClone-design.html`) is a **design reference built in HTML** — a working, interactive prototype of look, layout, and behavior. It is NOT production code to paste into the repo. The task is to **recreate this design inside the existing Tauri GUI** (`crates/rusty_fclone-gui`), replacing its current vanilla-JS/HTML/CSS frontend (`ui/index.html`, `ui/app.js`, `ui/style.css`) while wiring it to the real Tauri commands already implemented in `crates/rusty_fclone-gui/src/commands.rs` and the wire types in `src/payload.rs`. The existing frontend has no framework (plain JS + Tauri's `invoke`/`listen` bridge) — either continue in vanilla JS/CSS matching this design pixel-for-pixel, or introduce a lightweight framework if the team prefers; either way, all real data must come from the existing Tauri commands, not be mocked.

## Fidelity
**High-fidelity.** Colors, typography, spacing, and component states in the HTML file are final and should be recreated precisely. Copy/wording is close to final; adjust only where it needs to reflect real backend semantics (see "Grounding in the real backend" below).

## Grounding in the real backend — read before implementing
This design was built against the actual `rusty_fclone` repo (`baileyrd/rusty_fclone`, branch `main`). Key facts the implementation MUST respect:

- **Action kinds are Delete / Hardlink / Reflink**, not just delete (`ACTION_KINDS` in the current `app.js`; `ActionKind` in `rusty_fclone_core::action`). The Review screen's segmented control for file-level duplicate groups reflects this.
- **Folder-level duplicate detection is real** (ADR-0021): the engine reports `FolderMatch::Exact` (2+ mutually-identical directories) and `FolderMatch::Contained` (subset fully inside a superset). ADR-0021 explicitly scopes this to **detection and reporting only — no folder-level delete action exists in the engine today** (per-file actions on the underlying `DuplicateGroup`s are the only real mechanism). **This design's mockup includes a "Delete Duplicate Folder" button per explicit product direction from the project owner, which is a deliberate deviation from ADR-0021.** Whoever implements this needs to either (a) get the ADR revisited/superseded to add a real folder-level action to `rusty_fclone_core`, or (b) treat the button as calling the existing per-file action pipeline against every file in the folder's underlying duplicate groups. Flag this decision back to the team before wiring it up.
- **Scan options already support a hash cache and fclones-cache import** (`ScanOptionsPayload.cachePath` / `fclonesImportPath`, ADR-0016 / ADR-0019). The Scan Setup screen's "Data & caching" section (Hash cache path, Import fclones cache) maps directly to these two existing fields — wire them straight through.
- **Scan history exists via SQLite** (ADR-0017), opt-in via `--history <path>`, CLI-only today, summary-level only (no per-file/per-group detail), and there is **no query/report subcommand yet** — reading it back is out of scope of that ADR. The Dashboard's "Import history" / "Export (JSON)" buttons are aspirational UI for this and the CLI's `--format json` output; the actual data plumbing (a GUI-side reader for the history DB, and a real export of the current scan's `DuplicateGroup`s to JSON) will need new backend work to back them.
- Wire types to reuse: `ScanEventPayload` (`duplicate_group` / `progress` / `error` / `finished`), `ActionResultPayload` (`plan` + optional `applied`), `GroupPayload` — all in `crates/rusty_fclone-gui/src/payload.rs`. Don't invent new payload shapes where these already cover the need.

## Screens / Views

### 1. Dashboard (`isDashboard`)
**Purpose:** At-a-glance summary of duplicate storage and recent scan activity; entry point to a new scan.
**Layout:** Single column, `gap: 16px`. Header row (title + subtitle left, primary button right) → 3-up stat card row (`gap: 16px`, each `flex: 1`) → full-width "Storage breakdown" card → full-width "Recent scans" card.
**Components:**
- Header: "Overview" (24px/800) + "Here's what's taking up space on this Mac." (13px, secondary text) left; "New Scan" primary button right (see Design Tokens → Buttons).
- Stat cards (×3): surface card (12px radius, 1px border, 18px/20px padding), 12px/600 secondary-color label, then a big value (26px/800) — "Duplicates found" (value + " files" in tertiary 14px), "Space to reclaim" (value in success color), "Last scan" (plain value).
- Storage breakdown card: title (14px/700) + a 10px-tall, fully-rounded (`border-radius: 99px`) horizontal stacked bar with 4 segments (accent/purple/warning/neutral-gray, widths 62/21/11/6%), then a legend row of 4 items (8px dot + "{label} {pct}%", 12px secondary).
- Recent scans card: header row with title left, "Import history" and "Export (JSON)" ghost buttons right (icon + label, 1px border, 8px radius, 8px/14px padding). Below: a 5-column grid table (`1.3fr 1.3fr 1fr 1fr 0.8fr`) — Location / Date / Duplicates / Reclaimable / Status — header row in 11px/700 uppercase tertiary text, then one row per scan with a top border, Status rendered as a pill badge (success-tinted background, success text, 99px radius).

### 2. Scan Setup (`isScan`)
**Purpose:** Choose scan locations and tuning options before running a scan.
**Layout:** Header, then a two-column row (`gap: 20px`, `flex: 1`): left "Folders to scan" card (`flex: 1`), right "Match sensitivity" + "File types" + toggles card (fixed `340px`). Below that, full-width "Data & caching" card. Footer bar (surface card, flex row, space-between): estimate text left, "Start Scan" primary button (large) right.
**Components:**
- Folder row: 18×18 custom checkbox (accent fill + white check when checked, else transparent w/ soft border), name (13px/600) + path (12px, tertiary) stacked, whole row clickable. "+ Add Folder" dashed-border button below the list, accent text.
- Match sensitivity: two-segment pill control ("Exact match" / "Similar content") — inactive segment transparent, active segment gets the window-background color + a small shadow (an "elevated pill" look, works in both themes).
- File types: wrapping row of pill chips (Photos/Videos/Documents/Audio/Archives) — selected chips get accent-tinted background/border/text, unselected use surface2/tertiary/soft-border.
- Two toggle rows (Include subfolders, Skip system files): label left, 36×20 pill switch right (accent when on, surface2 when off; white 16px knob with a subtle shadow).
- Data & caching card: title + 12px tertiary description, then two side-by-side fields ("Hash cache path", "Import fclones cache"), each a text input (window-bg, soft border, 8px radius) + a "Browse" ghost button.

### 3. Duplicate Review (`isReview`)
**Purpose:** Step through duplicate groups (files and folders) and resolve each with a real action.
**Layout:** Header row (title/subtitle left; prev/next 32×32 icon buttons + "Group X of N" right). Below: two-column row (`gap: 20px`, `flex: 1`, `overflow: hidden`) — left a `220px` scrollable group-list card, right a column (`gap: 14px`) containing the compare area (flex row of file/folder cards, `gap: 16px`) and a bottom action bar.
**Components:**
- Group list row: colored swatch (34×34, 8px radius, kind-tinted background+icon color — folder rows show a folder glyph), name (13px/600, truncated) + "2 copies · {size}" (11px tertiary). Active row gets an accent-tinted background + accent border.
- Compare card (one per file/folder, side by side): border is solid success when `keep`, dashed danger when not; 64×64 icon tile (file or folder glyph, tinted by the group's kind color); uppercase label ("Copy A"/"Folder A", 12px/700 tertiary); path (13px/600, `word-break: break-all`); metadata rows (Size always; Modified+Details for files, Items count + a truncated file-name preview string for folders); a full-width badge at the bottom ("Keeping this file/folder" success-tinted, or "Marked for removal" danger-tinted) — **clicking a card's badge sets that side as the one to keep** (mutually exclusive within the group).
- Bottom action bar (surface card, flex row, space-between):
  - Folder groups: a pink-tinted "Exact folder match" / "Contained folder match" pill badge, then the reclaim text, then Skip + "Delete Duplicate Folder" (danger button) — see the ADR-0021 caveat above before wiring this to a real command.
  - File groups: a 3-segment Delete/Hardlink/Reflink control (same "elevated active pill" pattern as Match sensitivity) instead of the badge, then reclaim text ("1 file will be {removed/hardlinked/reflinked} · reclaims {size}" — size in success color), then Skip + "Apply {Kind}" (danger-colored button, label follows the selected action kind).

### 4. Rules & Automation (`isRules`)
**Purpose:** View/toggle automation rules applied on future scans.
**Layout:** Header (title/subtitle left, "+ Add Rule" primary button right), then a vertical list of rule cards (`gap: 20px` from header, cards have no inter-card gap defined beyond their own margin — recreate as a column with consistent spacing), footer note centered below.
**Components:** Rule card: 38×38 icon tile (accent-tinted when enabled, surface2/tertiary when disabled) with a shield glyph; title (14px/700) + description (12px, secondary) in the middle; a 36×20 toggle switch on the right (same switch component as Scan Setup).

## Interactions & Behavior
- Sidebar nav (Dashboard/Scan/Review/Rules) switches the visible screen; active item gets an accent-tinted background, accent icon color, and full-brightness text.
- Scan Setup: folder checkboxes, file-type chips, match-sensitivity segment, and both toggles are all independently stateful and click-toggle.
- Review: prev/next arrows and clicking a group-list row both change the active group (wraps around at the ends). Clicking either file/folder card's badge flips which side is "kept" (the other becomes "marked for removal") within that group only. The action-kind segmented control (file groups only) is global scan-wide state in this prototype; per-group override is a reasonable enhancement but out of scope of the mock. "Skip"/"Apply.../"Delete..." currently just advance to the next group (no real deletion is implemented in the mock — wire to `run_action`/a new folder-scoped command per group in the real build).
- Rules: each rule's toggle flips independently; "+ Add Rule" has no behavior in the mock (needs a real add-rule flow).
- No loading/error states are mocked — the real implementation should show scan progress (`ScanEventPayload::Progress`), per-file errors (`ScanEventPayload::Error`), and action results/failures (`ApplyReportPayload.failed`) using the existing payload shapes.
- No responsive behavior — this is a fixed-size desktop window (see below).

## State Management
Prototype state (React-style, for reference — re-derive in whatever the real frontend uses):
- `view`: `'dashboard' | 'scan' | 'review' | 'rules'`
- `groupIndex`: active duplicate group in Review
- `groups`: array of duplicate groups, each with `files: [{id, keep, ...}]` — `keep` flips exclusively within a group
- `folders`: scan-location checkboxes (`{id, name, path, checked}`)
- `chipSet`: selected file-type filter labels
- `matchMode`: `'exact' | 'similar'`
- `subfolders`, `skipSystem`: booleans
- `rules`: array of `{id, title, desc, enabled}`
- `actionKind`: `'delete' | 'hardlink' | 'reflink'` (global in the mock; real app should probably scope this per group/session)
- Theme: `mode: 'dark' | 'light'`, `palette: [accent, success, danger, warning, purple, pink]` (6 hex strings) — see Design Tokens.

Real data requirements: replace all mock arrays with data from `scan-event` (`duplicate_group` payloads accumulate into `groups`), `folder_dedup::find_folder_duplicates` results for the folder-match groups, and `run_action`'s `ActionResultPayload` for outcomes.

## Design Tokens

### Theme neutrals (light/dark — swap as a set)
| Token | Dark | Light |
|---|---|---|
| page (outer backdrop) | `#0a0b0d` | `#eef0f3` |
| window bg | `#0f1115` | `#ffffff` |
| titlebar bg | `#101318` | `#f8f9fb` |
| sidebar bg | `#121417` | `#f7f8fa` |
| surface (cards) | `#171a1f` | `#f7f8fa` |
| surface2 (chips/tracks off) | `#21252c` | `#e7e9ed` |
| border (strong, card outlines) | `#1e222a` | `#e5e7eb` |
| border (soft, inputs/dashed) | `#2a2f37` | `#d8dbe0` |
| text primary | `#f1f2f4` | `#16181d` |
| text secondary | `#9aa0ab` | `#5b616b` |
| text tertiary | `#6b7280` | `#8b909a` |
| input/track bg | `#0f1115` | `#eef0f3` |
| "other" chart gray | `#3a4048` | `#cbd5e1` |
| window shadow | `0 40px 100px rgba(0,0,0,.6), 0 0 0 1px rgba(255,255,255,.06)` | `0 30px 70px rgba(16,20,30,.12), 0 0 0 1px rgba(16,20,30,.06)` |

### Accent palettes (accent, success, danger, warning, purple, pink) — pick one, or offer all 5 as a theme picker
1. **Indigo (default):** `#5b8cff #34d399 #f87171 #fbbf24 #a78bfa #f472b6`
2. **Teal:** `#2dd4bf #4ade80 #fb7185 #fbbf24 #38bdf8 #c084fc`
3. **Violet:** `#a78bfa #34d399 #fb7185 #fbbf24 #818cf8 #f0abfc`
4. **Amber:** `#f59e0b #34d399 #f87171 #fb923c #c084fc #fb7185`
5. **Slate:** `#94a3b8 #4ade80 #f87171 #fbbf24 #a1a1aa #cbd5e1`

Duplicate "kind" → palette slot mapping (drives group swatch/icon color): photo→accent, document→warning, video→purple, audio→success, folder→pink.

### Typography
- Font: **Manrope** (Google Fonts, weights 400/500/600/700/800), fallback `sans-serif`.
- Scale used: 11px (uppercase labels/eyebrows), 12px (secondary/meta), 13px (body/buttons), 14px (card titles/rule titles), 15px (wordmark), 24px (screen titles), 26px (stat values) — weights 500–800 depending on role (see per-component notes above).

### Radii & spacing
- Window: 16px. Cards: 12px. Buttons/inputs/chips: 7–9px. Pills/badges/switches: 99px (fully round). Icon tiles: 8–10px.
- Standard card padding: `18–20px`. Section gaps: 16–22px. Sidebar width: `232px`. Review group-list width: `220px`. Scan-options column width: `340px`.
- Window canvas size: **1280×820px** (fixed desktop window mockup — real app window is of course resizable; treat 1280×820 as the reference/default size).

### Buttons
- Primary: accent background, white text, 700 weight, 9px radius, `10px 18px` padding (`12px 26px` for the large Start Scan variant).
- Ghost: transparent background, 1px soft border, secondary text color, same radius/padding as primary.
- Danger/destructive: danger-color background, white text (used for the Confirm/Apply/Delete actions in Review).

## Assets
No external images — every icon (nav glyphs, folder/file icons, arrows, gear, magnifier-less "scan" viewfinder icon, shield for rules) is a small inline SVG, stroke-based, `currentColor`/theme-token colored, 13–30px. macOS-style traffic-light dots (red/yellow/green) are plain colored circles, not real macOS assets. No photos, logos, or illustrations are used — recreate the icons as inline SVGs or swap in the codebase's existing icon set if it has equivalents.

## Files
- `RustyFClone-design.html` — the full interactive design reference (Dashboard, Scan Setup, Duplicate Review, Rules), including the light/dark and 5-palette theme system described above. Open directly in a browser to explore all states.
- `screenshots/01-dashboard.png`, `02-scan-setup.png`, `03-duplicate-review.png` (file-level group), `04-review-folder-match.png` (folder-level group), `05-rules.png` — static reference captures of each screen, dark theme, default Indigo palette.
